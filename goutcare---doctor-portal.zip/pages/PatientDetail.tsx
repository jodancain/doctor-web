import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { MOCK_PATIENTS } from '../constants';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine } from 'recharts';
import { ArrowLeft, FileText, Activity, AlertCircle } from 'lucide-react';

const PatientDetail: React.FC = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const patient = MOCK_PATIENTS.find(p => p.id === id);

  if (!patient) return <div className="p-8 text-center text-slate-500">未找到患者信息</div>;

  return (
    <div className="space-y-6">
      <button 
        onClick={() => navigate('/patients')}
        className="flex items-center text-slate-500 hover:text-primary-600 transition-colors mb-2"
      >
        <ArrowLeft size={18} className="mr-1" /> 返回列表
      </button>

      {/* Header Info */}
      <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-full bg-primary-100 text-primary-600 flex items-center justify-center font-bold text-2xl">
             {patient.name.substring(0, 1)}
          </div>
          <div>
            <h1 className="text-2xl font-bold text-slate-800 flex items-center gap-3">
              {patient.name}
              <span className={`text-xs px-2 py-1 rounded-full font-normal ${
                patient.status === 'Stable' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
              }`}>
                {patient.status === 'Stable' ? '病情稳定' : '需要关注'}
              </span>
            </h1>
            <p className="text-slate-500 mt-1">
              {patient.gender === 'Male' ? '男' : '女'} | {patient.age}岁 | ID: {patient.id}
            </p>
          </div>
        </div>
        <div className="flex gap-3">
          <button 
            onClick={() => navigate(`/patients/edit/${patient.id}`)}
            className="px-4 py-2 border border-slate-200 rounded-xl text-slate-600 hover:bg-slate-50 font-medium transition-colors"
          >
            编辑档案
          </button>
          <button className="px-4 py-2 bg-primary-600 text-white rounded-xl hover:bg-primary-700 font-medium shadow-sm">
            发起复诊
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Chart Section */}
        <div className="lg:col-span-2 bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
          <div className="flex items-center justify-between mb-6">
            <h3 className="font-bold text-slate-800 flex items-center gap-2">
              <Activity size={20} className="text-primary-600" />
              血尿酸历史趋势
            </h3>
          </div>
          <div className="h-[350px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={patient.history} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis 
                  dataKey="date" 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fill: '#94a3b8', fontSize: 12 }} 
                  dy={10}
                />
                <YAxis 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fill: '#94a3b8', fontSize: 12 }} 
                />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#fff', borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                  itemStyle={{ color: '#1e293b' }}
                />
                <ReferenceLine y={patient.targetUricAcid} stroke="#10b981" strokeDasharray="5 5" label={{ value: `目标 < ${patient.targetUricAcid}`, fill: '#10b981', fontSize: 12, position: 'insideTopRight' }} />
                <Area 
                  type="monotone" 
                  dataKey="value" 
                  stroke="#3b82f6" 
                  strokeWidth={3}
                  fillOpacity={1} 
                  fill="url(#colorValue)" 
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Clinical Summary */}
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
             <h3 className="font-bold text-slate-800 mb-4 flex items-center gap-2">
               <FileText size={20} className="text-primary-600" />
               临床摘要
             </h3>
             <div className="space-y-4">
               <div>
                 <span className="text-xs text-slate-400 block uppercase tracking-wider mb-1">主要诊断</span>
                 <p className="font-medium text-slate-800">{patient.diagnosis}</p>
               </div>
               <div>
                 <span className="text-xs text-slate-400 block uppercase tracking-wider mb-1">当前用药</span>
                 <p className="font-medium text-slate-800 bg-slate-50 p-3 rounded-lg border border-slate-100 text-sm">
                   {patient.medication}
                 </p>
               </div>
               <div className="pt-2 border-t border-slate-100">
                 <div className="flex items-start gap-3 mt-2 text-sm text-slate-600 bg-orange-50 p-3 rounded-lg">
                   <AlertCircle size={16} className="text-orange-500 mt-0.5 flex-shrink-0" />
                   <p>患者上次复诊尿酸仍未达标，建议评估患者用药依从性，或考虑联合降尿酸治疗。</p>
                 </div>
               </div>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PatientDetail;