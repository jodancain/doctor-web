import React, { useState } from 'react';
import { Search, Filter, Eye, UserPlus, X, Copy, Edit2, Trash2 } from 'lucide-react';
import { MOCK_PATIENTS } from '../constants';
import { useNavigate } from 'react-router-dom';

const PatientList: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [showQRCode, setShowQRCode] = useState(false);
  const [copied, setCopied] = useState(false);
  const navigate = useNavigate();

  const filteredPatients = MOCK_PATIENTS.filter(p => 
    p.name.includes(searchTerm) || p.id.includes(searchTerm)
  );

  const handleCopy = () => {
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Toolbar */}
      <div className="flex flex-col md:flex-row justify-between gap-4">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-3 text-slate-400" size={20} />
          <input 
            type="text" 
            placeholder="搜索患者姓名、ID..." 
            className="w-full pl-10 pr-4 py-2.5 bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-500"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="flex gap-2">
          <button className="flex items-center px-4 py-2.5 bg-white border border-slate-200 text-slate-600 rounded-xl hover:bg-slate-50 font-medium">
            <Filter size={18} className="mr-2" />
            筛选
          </button>
          <button 
            onClick={() => setShowQRCode(true)}
            className="flex items-center px-4 py-2.5 bg-primary-600 text-white rounded-xl hover:bg-primary-700 font-medium shadow-sm shadow-primary-500/30"
          >
            <UserPlus size={18} className="mr-2" />
            新增患者
          </button>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead className="bg-slate-50 border-b border-slate-200">
              <tr>
                <th className="px-6 py-4 text-xs font-semibold text-slate-500 uppercase">患者信息</th>
                <th className="px-6 py-4 text-xs font-semibold text-slate-500 uppercase">诊断/状态</th>
                <th className="px-6 py-4 text-xs font-semibold text-slate-500 uppercase">当前尿酸</th>
                <th className="px-6 py-4 text-xs font-semibold text-slate-500 uppercase">用药方案</th>
                <th className="px-6 py-4 text-xs font-semibold text-slate-500 uppercase">最近就诊</th>
                <th className="px-6 py-4 text-right text-xs font-semibold text-slate-500 uppercase">操作</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredPatients.map((patient) => (
                <tr key={patient.id} className="hover:bg-slate-50/50 transition-colors">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-primary-100 text-primary-600 flex items-center justify-center font-bold text-sm">
                        {patient.name.substring(0, 1)}
                      </div>
                      <div>
                        <div className="font-bold text-slate-800">{patient.name}</div>
                        <div className="text-xs text-slate-500">{patient.gender === 'Male' ? '男' : '女'} · {patient.age}岁 · {patient.id}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="text-sm text-slate-800 font-medium">{patient.diagnosis}</div>
                    <span className={`inline-flex items-center mt-1 px-2 py-0.5 rounded text-xs font-medium ${
                      patient.status === 'Critical' ? 'bg-red-100 text-red-700' :
                      patient.status === 'Risk' ? 'bg-orange-100 text-orange-700' :
                      'bg-green-100 text-green-700'
                    }`}>
                      {patient.status === 'Critical' ? '急性期' : 
                       patient.status === 'Risk' ? '未达标' : '稳定'}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className={`font-bold text-lg ${
                      patient.lastUricAcid > patient.targetUricAcid ? 'text-red-600' : 'text-slate-800'
                    }`}>
                      {patient.lastUricAcid}
                    </div>
                    <div className="text-xs text-slate-400">目标: &lt;{patient.targetUricAcid}</div>
                  </td>
                  <td className="px-6 py-4 max-w-xs truncate text-sm text-slate-600" title={patient.medication}>
                    {patient.medication}
                  </td>
                  <td className="px-6 py-4 text-sm text-slate-500">
                    {patient.lastVisit}
                  </td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex items-center justify-end gap-2">
                      <button 
                        onClick={() => navigate(`/patients/${patient.id}`)}
                        className="text-slate-400 hover:text-primary-600 p-2 hover:bg-primary-50 rounded-lg transition-colors"
                        title="查看详情"
                      >
                        <Eye size={18} />
                      </button>
                      <button 
                        onClick={() => navigate(`/patients/edit/${patient.id}`)}
                        className="text-slate-400 hover:text-primary-600 p-2 hover:bg-primary-50 rounded-lg transition-colors"
                        title="编辑档案"
                      >
                        <Edit2 size={18} />
                      </button>
                      <button 
                        className="text-slate-400 hover:text-red-600 p-2 hover:bg-red-50 rounded-lg transition-colors"
                        title="删除患者"
                      >
                        <Trash2 size={18} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* QR Code Modal */}
      {showQRCode && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm animate-fade-in" onClick={() => setShowQRCode(false)}>
          <div className="bg-white rounded-3xl shadow-2xl w-full max-w-[400px] overflow-hidden relative transform transition-all scale-100" onClick={e => e.stopPropagation()}>
             {/* Header */}
             <div className="flex justify-center pt-6 pb-2 relative">
               <h3 className="text-lg text-slate-600 font-normal">我的二维码</h3>
               <button 
                 onClick={() => setShowQRCode(false)}
                 className="absolute right-5 top-6 text-slate-400 hover:text-slate-600 transition-colors"
               >
                 <X size={20} />
               </button>
             </div>
             
             <div className="p-8">
               {/* Doctor Info Section */}
               <div className="flex items-center gap-6 mb-10">
                 <div className="w-[88px] h-[88px] rounded-full bg-slate-100 shrink-0 overflow-hidden shadow-sm border border-slate-50">
                    <img 
                      src="https://ui-avatars.com/api/?name=Dr+Wang&background=0D8ABC&color=fff&size=200" 
                      className="w-full h-full object-cover" 
                      alt="Avatar" 
                    />
                 </div>
                 <div className="space-y-1.5">
                   <h4 className="text-xl text-slate-700 font-normal">王主任</h4>
                   <p className="text-xs text-slate-500">副主任医师&nbsp;&nbsp;&nbsp;南方医科大学珠江医院</p>
                   <p className="text-xs text-slate-500">南方医科大学珠江医院</p>
                 </div>
               </div>
               
               {/* QR Code Section */}
               <div className="flex justify-center mb-6">
                 <div className="w-[220px] h-[220px] bg-slate-50">
                   {/* Generating a styled QR code similar to the image */}
                   <img 
                     src="https://api.qrserver.com/v1/create-qr-code/?size=220x220&data=https://goutcare.health/doctor/dr-wang&color=000000&bgcolor=ffffff&margin=5" 
                     alt="QR Code" 
                     className="w-full h-full mix-blend-multiply"
                   />
                 </div>
               </div>
               
               <p className="text-xs text-slate-500 text-center mb-8 tracking-wide">扫一扫，成为我的患者</p>
               
               <div className="flex justify-center">
                 <button 
                   onClick={handleCopy}
                   className="px-8 py-2 bg-primary-500 text-white rounded-md text-sm font-normal hover:bg-primary-600 transition-colors shadow-md shadow-primary-500/20 active:scale-95 duration-200"
                 >
                   {copied ? '已复制' : '复制二维码'}
                 </button>
               </div>
             </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default PatientList;